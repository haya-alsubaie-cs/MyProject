# Simple Calculator

# Ask user for input
a = float(input("Enter first number: "))
b = float(input("Enter second number: "))
op = input("Choose operation (+, -, *, /): ")

# Perform calculation
if op == "+":
    result = a + b
elif op == "-":
    result = a - b
elif op == "*":
    result = a * b
elif op == "/":
    if b != 0:
        result = a / b
    else:
        result = "Error: Cannot divide by zero"
else:
    result = "Error: Invalid operation"

# Show result
print("Result:", result)